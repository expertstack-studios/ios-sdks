//
//  SecuredVideoCallsSDK.h
//  SecuredVideoCallsSDK
//
//  Created by Vivek Lalan on 29/05/24.
//

#import <Foundation/Foundation.h>

//! Project version number for videocall.
FOUNDATION_EXPORT double videocallVersionNumber;

//! Project version string for videocall.
FOUNDATION_EXPORT const unsigned char videocallVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <videocall/PublicHeader.h>


